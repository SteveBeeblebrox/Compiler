# Run using:
# mtsc -pcomment src/index.ts -o- | node

# MTSC can be found here:
# https://github.com/SteveBeeblebrox/mtsc

echo 'Build.sh NYI!'
exit 1